# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.
from iopath.common.download import download


__all__ = ["download"]
